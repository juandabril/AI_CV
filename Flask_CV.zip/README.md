# cv-static-aws
